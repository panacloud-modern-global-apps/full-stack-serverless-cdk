# pip install mysql-connector-python
import os
import mysql.connector

value = os.environ["INSTANCE_CREDENTIALS"]
envvalue = json.dumps(value)
print(envvalue)

#  Require and initialize outside of your main handler
mydb = mysql.connector.connect(
  host="localhost",
  user="admin",
  database= envvalue["dbname"],
  password= envvalue["password"],
)
# const mysql = require("serverless-mysql")({
#   config: {
#     host: env.HOST,
#     database: envvalue.dbname,
#     user: "admin",
#     password: envvalue.password,
#   },
# });

def handler(event, context):
    # // Connect to your MySQL instance first
    # await mysql.connect();
    # // Get the connection object
    # // let connection = mysql.getClient()
    mycursor = mydb.cursor()

    #  Simple query
    resultsa = mycursor.execute(
      "CREATE TABLE IF NOT EXISTS new (task_id INT AUTO_INCREMENT, description TEXT, PRIMARY KEY (task_id))"
    )

    print(resultsa, "results from database")

    # //  close the connection
   

    # // first query
    # // "CREATE TABLE IF NOT EXISTS new (task_id INT AUTO_INCREMENT, description TEXT, PRIMARY KEY (task_id))"
    # // second query
    # // "insert into new (task_id, description) values(20,'complete the project')",
    # mydb.commit()
    # Important!: Notice the statement: mydb.commit(). It is required to make the changes, otherwise no changes are made to the table.
    # // third query
    # // "SELECT * FROM new"

    return {
      'statusCode': 200,
      'headers' : json.dumps({ "Content-Type": "text/plain" }),
      'body': json.dumps(resultsa)
    }

