"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const process_1 = require("process");
const value = process_1.env.vala || "ll";
const envvalue2 = JSON.parse(value);
// Require and initialize outside of your main handler
const mysql = require("serverless-mysql")({
    config: {
        host: envvalue2.host,
        database: envvalue2.dbname,
        user: "admin",
        password: envvalue2.password,
    },
});
async function handler(event, context) {
    console.log(process_1.env.vala, "vala");
    console.log(envvalue2, "val2");
    // If you're using AWS Lambda with callbacks, be sure to set context.callbackWaitsForEmptyEventLoop = false; in your main handler. This will allow the freezing of connections and will prevent Lambda from hanging on open connections. See here for more information. If you are using async functions, this is no longer necessary.
    // context.callbackWaitsForEmptyEventLoop = false;
    try {
        // Connect to your MySQL instance first
        await mysql.connect();
        // Get the connection object
        // let connection = mysql.getClient()
        // Simple query
        let resultsa = await mysql.query("CREATE TABLE IF NOT EXISTS new (task_id INT AUTO_INCREMENT, description TEXT, PRIMARY KEY (task_id))");
        // let resultsb = await mysql.query(
        //   "insert into new (task_id, description) values(20,'important')"
        // );
        // Query with advanced options
        // let resultsc= await connect.query({
        //   sql: 'SELECT * FROM table WHERE name = ?',
        //   timeout: 10000,
        //   values: ['serverless']
        // })
        // let results = await mysql.query("SELECT * FROM new");
        console.log(resultsa, "results from database");
        //  close the connection
        await mysql.end();
        // first query
        // "CREATE TABLE IF NOT EXISTS new (task_id INT AUTO_INCREMENT, description TEXT, PRIMARY KEY (task_id))"
        // second query
        // "insert into new (task_id, description) values(20,'humddda')",
        // third query
        // "SELECT * FROM new"
        return {
            statusCode: 200,
            headers: { "Content-Type": "text/plain" },
            body: `Hello, CDK! You've created ${JSON.stringify(resultsa, null, 2)}\n`,
        };
    }
    catch (e) {
        console.log(e, "error from lambda");
        return {
            statusCode: 200,
            headers: { "Content-Type": "text/plain" },
            body: `Hello, CDK! You've created${JSON.stringify(e, null, 2)} \n`,
        };
    }
}
exports.handler = handler;
// ***************************************************************************************************************
// Transaction support in serverless-mysql has been dramatically simplified. Start a new transaction using the transaction() method, and then chain queries using the query() method. The query() method supports all standard query options. Alternatively, you can specify a function as the only argument in a query() method call and return the arguments as an array of values. The function receives two arguments, the result of the last query executed and an array containing all the previous query results. This is useful if you need values from a previous query as part of your transaction.
// You can specify an optional rollback() method in the chain. This will receive the error object, allowing you to add additional logging or perform some other action. Call the commit() method when you are ready to execute the queries.
// let results = await mysql.transaction()
//   .query('INSERT INTO table (x) VALUES(?)', [1])
//   .query('UPDATE table SET x = 1')
//   .rollback(e => { /* do something with the error */ }) // optional
//   .commit() // execute the queries
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJpbmRleC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7QUFLQSxxQ0FBOEI7QUFFOUIsTUFBTSxLQUFLLEdBQUcsYUFBRyxDQUFDLElBQUksSUFBSSxJQUFJLENBQUM7QUFDL0IsTUFBTSxTQUFTLEdBQVEsSUFBSSxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQztBQUV6QyxzREFBc0Q7QUFDdEQsTUFBTSxLQUFLLEdBQUcsT0FBTyxDQUFDLGtCQUFrQixDQUFDLENBQUM7SUFDeEMsTUFBTSxFQUFFO1FBQ04sSUFBSSxFQUFFLFNBQVMsQ0FBQyxJQUFJO1FBQ3BCLFFBQVEsRUFBRSxTQUFTLENBQUMsTUFBTTtRQUMxQixJQUFJLEVBQUUsT0FBTztRQUNiLFFBQVEsRUFBRSxTQUFTLENBQUMsUUFBUTtLQUM3QjtDQUNGLENBQUMsQ0FBQztBQUVJLEtBQUssVUFBVSxPQUFPLENBQzNCLEtBQTJCLEVBQzNCLE9BQWdCO0lBRWhCLE9BQU8sQ0FBQyxHQUFHLENBQUMsYUFBRyxDQUFDLElBQUksRUFBRSxNQUFNLENBQUMsQ0FBQTtJQUM3QixPQUFPLENBQUMsR0FBRyxDQUFDLFNBQVMsRUFBRSxNQUFNLENBQUMsQ0FBQTtJQUM5QixzVUFBc1U7SUFDdFUsa0RBQWtEO0lBQ2xELElBQUk7UUFDRix1Q0FBdUM7UUFDdkMsTUFBTSxLQUFLLENBQUMsT0FBTyxFQUFFLENBQUM7UUFDdEIsNEJBQTRCO1FBQzVCLHFDQUFxQztRQUVyQyxlQUFlO1FBQ2YsSUFBSSxRQUFRLEdBQUcsTUFBTSxLQUFLLENBQUMsS0FBSyxDQUM5QixzR0FBc0csQ0FDdkcsQ0FBQztRQUVGLG9DQUFvQztRQUNwQyxvRUFBb0U7UUFDcEUsS0FBSztRQUVMLDhCQUE4QjtRQUM5QixzQ0FBc0M7UUFDdEMsK0NBQStDO1FBQy9DLG9CQUFvQjtRQUNwQiwyQkFBMkI7UUFDM0IsS0FBSztRQUVMLHdEQUF3RDtRQUV4RCxPQUFPLENBQUMsR0FBRyxDQUFDLFFBQVEsRUFBRSx1QkFBdUIsQ0FBQyxDQUFDO1FBRS9DLHdCQUF3QjtRQUN4QixNQUFNLEtBQUssQ0FBQyxHQUFHLEVBQUUsQ0FBQztRQUVsQixjQUFjO1FBQ2QseUdBQXlHO1FBRXpHLGVBQWU7UUFDZixpRUFBaUU7UUFFakUsY0FBYztRQUNkLHNCQUFzQjtRQUV0QixPQUFPO1lBQ0wsVUFBVSxFQUFFLEdBQUc7WUFDZixPQUFPLEVBQUUsRUFBRSxjQUFjLEVBQUUsWUFBWSxFQUFFO1lBQ3pDLElBQUksRUFBRSw4QkFBOEIsSUFBSSxDQUFDLFNBQVMsQ0FBQyxRQUFRLEVBQUUsSUFBSSxFQUFFLENBQUMsQ0FBQyxJQUFJO1NBQzFFLENBQUM7S0FDSDtJQUFDLE9BQU8sQ0FBQyxFQUFFO1FBQ1YsT0FBTyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQUUsbUJBQW1CLENBQUMsQ0FBQztRQUNwQyxPQUFPO1lBQ0wsVUFBVSxFQUFFLEdBQUc7WUFDZixPQUFPLEVBQUUsRUFBRSxjQUFjLEVBQUUsWUFBWSxFQUFFO1lBQ3pDLElBQUksRUFBRSw2QkFBNkIsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLEVBQUUsSUFBSSxFQUFFLENBQUMsQ0FBQyxLQUFLO1NBQ25FLENBQUM7S0FDSDtBQUNILENBQUM7QUEzREQsMEJBMkRDO0FBQ0Qsa0hBQWtIO0FBRWxILDZrQkFBNmtCO0FBRTdrQiwyT0FBMk87QUFDM08sMENBQTBDO0FBQzFDLG1EQUFtRDtBQUNuRCxxQ0FBcUM7QUFDckMsc0VBQXNFO0FBQ3RFLHFDQUFxQyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7XG4gIEFQSUdhdGV3YXlQcm94eUV2ZW50LFxuICBBUElHYXRld2F5UHJveHlSZXN1bHQsXG4gIENvbnRleHQsXG59IGZyb20gXCJhd3MtbGFtYmRhXCI7XG5pbXBvcnQgeyBlbnYgfSBmcm9tIFwicHJvY2Vzc1wiO1xuXG5jb25zdCB2YWx1ZSA9IGVudi52YWxhIHx8IFwibGxcIjtcbmNvbnN0IGVudnZhbHVlMjogYW55ID0gSlNPTi5wYXJzZSh2YWx1ZSk7XG5cbi8vIFJlcXVpcmUgYW5kIGluaXRpYWxpemUgb3V0c2lkZSBvZiB5b3VyIG1haW4gaGFuZGxlclxuY29uc3QgbXlzcWwgPSByZXF1aXJlKFwic2VydmVybGVzcy1teXNxbFwiKSh7XG4gIGNvbmZpZzoge1xuICAgIGhvc3Q6IGVudnZhbHVlMi5ob3N0LFxuICAgIGRhdGFiYXNlOiBlbnZ2YWx1ZTIuZGJuYW1lLFxuICAgIHVzZXI6IFwiYWRtaW5cIixcbiAgICBwYXNzd29yZDogZW52dmFsdWUyLnBhc3N3b3JkLFxuICB9LFxufSk7XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBoYW5kbGVyKFxuICBldmVudDogQVBJR2F0ZXdheVByb3h5RXZlbnQsXG4gIGNvbnRleHQ6IENvbnRleHRcbik6IFByb21pc2U8QVBJR2F0ZXdheVByb3h5UmVzdWx0PiB7XG4gIGNvbnNvbGUubG9nKGVudi52YWxhLCBcInZhbGFcIilcbiAgY29uc29sZS5sb2coZW52dmFsdWUyLCBcInZhbDJcIilcbiAgLy8gSWYgeW91J3JlIHVzaW5nIEFXUyBMYW1iZGEgd2l0aCBjYWxsYmFja3MsIGJlIHN1cmUgdG8gc2V0IGNvbnRleHQuY2FsbGJhY2tXYWl0c0ZvckVtcHR5RXZlbnRMb29wID0gZmFsc2U7IGluIHlvdXIgbWFpbiBoYW5kbGVyLiBUaGlzIHdpbGwgYWxsb3cgdGhlIGZyZWV6aW5nIG9mIGNvbm5lY3Rpb25zIGFuZCB3aWxsIHByZXZlbnQgTGFtYmRhIGZyb20gaGFuZ2luZyBvbiBvcGVuIGNvbm5lY3Rpb25zLiBTZWUgaGVyZSBmb3IgbW9yZSBpbmZvcm1hdGlvbi4gSWYgeW91IGFyZSB1c2luZyBhc3luYyBmdW5jdGlvbnMsIHRoaXMgaXMgbm8gbG9uZ2VyIG5lY2Vzc2FyeS5cbiAgLy8gY29udGV4dC5jYWxsYmFja1dhaXRzRm9yRW1wdHlFdmVudExvb3AgPSBmYWxzZTtcbiAgdHJ5IHtcbiAgICAvLyBDb25uZWN0IHRvIHlvdXIgTXlTUUwgaW5zdGFuY2UgZmlyc3RcbiAgICBhd2FpdCBteXNxbC5jb25uZWN0KCk7XG4gICAgLy8gR2V0IHRoZSBjb25uZWN0aW9uIG9iamVjdFxuICAgIC8vIGxldCBjb25uZWN0aW9uID0gbXlzcWwuZ2V0Q2xpZW50KClcblxuICAgIC8vIFNpbXBsZSBxdWVyeVxuICAgIGxldCByZXN1bHRzYSA9IGF3YWl0IG15c3FsLnF1ZXJ5KFxuICAgICAgXCJDUkVBVEUgVEFCTEUgSUYgTk9UIEVYSVNUUyBuZXcgKHRhc2tfaWQgSU5UIEFVVE9fSU5DUkVNRU5ULCBkZXNjcmlwdGlvbiBURVhULCBQUklNQVJZIEtFWSAodGFza19pZCkpXCJcbiAgICApO1xuXG4gICAgLy8gbGV0IHJlc3VsdHNiID0gYXdhaXQgbXlzcWwucXVlcnkoXG4gICAgLy8gICBcImluc2VydCBpbnRvIG5ldyAodGFza19pZCwgZGVzY3JpcHRpb24pIHZhbHVlcygyMCwnaW1wb3J0YW50JylcIlxuICAgIC8vICk7XG5cbiAgICAvLyBRdWVyeSB3aXRoIGFkdmFuY2VkIG9wdGlvbnNcbiAgICAvLyBsZXQgcmVzdWx0c2M9IGF3YWl0IGNvbm5lY3QucXVlcnkoe1xuICAgIC8vICAgc3FsOiAnU0VMRUNUICogRlJPTSB0YWJsZSBXSEVSRSBuYW1lID0gPycsXG4gICAgLy8gICB0aW1lb3V0OiAxMDAwMCxcbiAgICAvLyAgIHZhbHVlczogWydzZXJ2ZXJsZXNzJ11cbiAgICAvLyB9KVxuXG4gICAgLy8gbGV0IHJlc3VsdHMgPSBhd2FpdCBteXNxbC5xdWVyeShcIlNFTEVDVCAqIEZST00gbmV3XCIpO1xuXG4gICAgY29uc29sZS5sb2cocmVzdWx0c2EsIFwicmVzdWx0cyBmcm9tIGRhdGFiYXNlXCIpO1xuXG4gICAgLy8gIGNsb3NlIHRoZSBjb25uZWN0aW9uXG4gICAgYXdhaXQgbXlzcWwuZW5kKCk7XG5cbiAgICAvLyBmaXJzdCBxdWVyeVxuICAgIC8vIFwiQ1JFQVRFIFRBQkxFIElGIE5PVCBFWElTVFMgbmV3ICh0YXNrX2lkIElOVCBBVVRPX0lOQ1JFTUVOVCwgZGVzY3JpcHRpb24gVEVYVCwgUFJJTUFSWSBLRVkgKHRhc2tfaWQpKVwiXG5cbiAgICAvLyBzZWNvbmQgcXVlcnlcbiAgICAvLyBcImluc2VydCBpbnRvIG5ldyAodGFza19pZCwgZGVzY3JpcHRpb24pIHZhbHVlcygyMCwnaHVtZGRkYScpXCIsXG5cbiAgICAvLyB0aGlyZCBxdWVyeVxuICAgIC8vIFwiU0VMRUNUICogRlJPTSBuZXdcIlxuXG4gICAgcmV0dXJuIHtcbiAgICAgIHN0YXR1c0NvZGU6IDIwMCxcbiAgICAgIGhlYWRlcnM6IHsgXCJDb250ZW50LVR5cGVcIjogXCJ0ZXh0L3BsYWluXCIgfSxcbiAgICAgIGJvZHk6IGBIZWxsbywgQ0RLISBZb3UndmUgY3JlYXRlZCAke0pTT04uc3RyaW5naWZ5KHJlc3VsdHNhLCBudWxsLCAyKX1cXG5gLFxuICAgIH07XG4gIH0gY2F0Y2ggKGUpIHtcbiAgICBjb25zb2xlLmxvZyhlLCBcImVycm9yIGZyb20gbGFtYmRhXCIpO1xuICAgIHJldHVybiB7XG4gICAgICBzdGF0dXNDb2RlOiAyMDAsXG4gICAgICBoZWFkZXJzOiB7IFwiQ29udGVudC1UeXBlXCI6IFwidGV4dC9wbGFpblwiIH0sXG4gICAgICBib2R5OiBgSGVsbG8sIENESyEgWW91J3ZlIGNyZWF0ZWQke0pTT04uc3RyaW5naWZ5KGUsIG51bGwsIDIpfSBcXG5gLFxuICAgIH07XG4gIH1cbn1cbi8vICoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKlxuXG4vLyBUcmFuc2FjdGlvbiBzdXBwb3J0IGluIHNlcnZlcmxlc3MtbXlzcWwgaGFzIGJlZW4gZHJhbWF0aWNhbGx5IHNpbXBsaWZpZWQuIFN0YXJ0IGEgbmV3IHRyYW5zYWN0aW9uIHVzaW5nIHRoZSB0cmFuc2FjdGlvbigpIG1ldGhvZCwgYW5kIHRoZW4gY2hhaW4gcXVlcmllcyB1c2luZyB0aGUgcXVlcnkoKSBtZXRob2QuIFRoZSBxdWVyeSgpIG1ldGhvZCBzdXBwb3J0cyBhbGwgc3RhbmRhcmQgcXVlcnkgb3B0aW9ucy4gQWx0ZXJuYXRpdmVseSwgeW91IGNhbiBzcGVjaWZ5IGEgZnVuY3Rpb24gYXMgdGhlIG9ubHkgYXJndW1lbnQgaW4gYSBxdWVyeSgpIG1ldGhvZCBjYWxsIGFuZCByZXR1cm4gdGhlIGFyZ3VtZW50cyBhcyBhbiBhcnJheSBvZiB2YWx1ZXMuIFRoZSBmdW5jdGlvbiByZWNlaXZlcyB0d28gYXJndW1lbnRzLCB0aGUgcmVzdWx0IG9mIHRoZSBsYXN0IHF1ZXJ5IGV4ZWN1dGVkIGFuZCBhbiBhcnJheSBjb250YWluaW5nIGFsbCB0aGUgcHJldmlvdXMgcXVlcnkgcmVzdWx0cy4gVGhpcyBpcyB1c2VmdWwgaWYgeW91IG5lZWQgdmFsdWVzIGZyb20gYSBwcmV2aW91cyBxdWVyeSBhcyBwYXJ0IG9mIHlvdXIgdHJhbnNhY3Rpb24uXG5cbi8vIFlvdSBjYW4gc3BlY2lmeSBhbiBvcHRpb25hbCByb2xsYmFjaygpIG1ldGhvZCBpbiB0aGUgY2hhaW4uIFRoaXMgd2lsbCByZWNlaXZlIHRoZSBlcnJvciBvYmplY3QsIGFsbG93aW5nIHlvdSB0byBhZGQgYWRkaXRpb25hbCBsb2dnaW5nIG9yIHBlcmZvcm0gc29tZSBvdGhlciBhY3Rpb24uIENhbGwgdGhlIGNvbW1pdCgpIG1ldGhvZCB3aGVuIHlvdSBhcmUgcmVhZHkgdG8gZXhlY3V0ZSB0aGUgcXVlcmllcy5cbi8vIGxldCByZXN1bHRzID0gYXdhaXQgbXlzcWwudHJhbnNhY3Rpb24oKVxuLy8gICAucXVlcnkoJ0lOU0VSVCBJTlRPIHRhYmxlICh4KSBWQUxVRVMoPyknLCBbMV0pXG4vLyAgIC5xdWVyeSgnVVBEQVRFIHRhYmxlIFNFVCB4ID0gMScpXG4vLyAgIC5yb2xsYmFjayhlID0+IHsgLyogZG8gc29tZXRoaW5nIHdpdGggdGhlIGVycm9yICovIH0pIC8vIG9wdGlvbmFsXG4vLyAgIC5jb21taXQoKSAvLyBleGVjdXRlIHRoZSBxdWVyaWVzXG4iXX0=